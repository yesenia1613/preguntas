<?php
if($_REQUEST['group1'])
?>