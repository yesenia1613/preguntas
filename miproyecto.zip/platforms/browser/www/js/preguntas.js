
      function avisoreset() {
        if(confirm("¡ATENCIÓN!. Los datos del test se van a reiniciar.")) {
        document.formulario.reset();
        parent.location.reload();
        }
      }
      
      var group1 = "0"; 
      var group2 = "0"; 
      var group3 = "0"; 
      var group4 = "0"; 
      var group5 = "0";  
      
      function respuesta1(valor) 
      {group1 = valor}; 
      function respuesta2(valor) 
      {group2 = valor}; 
      function respuesta3(valor) 
      {group3 = valor}; 
      function respuesta4(valor) 
      {group4 = valor}; 
      function respuesta5(valor) 
      {group5 = valor}; 
 
      <script language="JavaScript" type="text/JavaScript">
        function MM_reloadPage(init) {  //reloads the window if Nav5 resized
          if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
            document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
          else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
        }
        MM_reloadPage(true);
        //-->
        </script>

        function examinar() 
      { 
      puntuacion=0; 
      nocontesta=0; 
      contestadas=0; 
      puntosmaximos=0; 
      
      if(group1!= "0" )
      {
        contestadas=contestadas+1
        puntosmaximos=puntosmaximos+10
        if(group1 == "A") {puntuacion=puntuacion+0}
        if(group1 == "B") {puntuacion=puntuacion+0}
        if(group1 == "C") {puntuacion=puntuacion+10}
        
      }
      else {nocontesta=nocontesta+1} 
      
      if(group2 != "0")
      {
        contestadas=contestadas+1
        puntosmaximos=puntosmaximos+10
        if(group2 == "A") {puntuacion=puntuacion+0}
        if(group2 == "B") {puntuacion=puntuacion+10}
        if(group2 == "C") {puntuacion=puntuacion+0}
        
      }
      else {nocontesta=nocontesta+1}
      
      if(group3!= "0" )
      {
        contestadas=contestadas+1
        puntosmaximos=puntosmaximos+10
        if(group3 == "A") {puntuacion=puntuacion+10}
        if(group3 == "B") {puntuacion=puntuacion+0}
        if(group3 == "C") {puntuacion=puntuacion+0}
      
      }
      else {nocontesta=nocontesta+1} 
      
      if(group4 != "0")
      {
        contestadas=contestadas+1
        puntosmaximos=puntosmaximos+10
        if(group4 == "A") {puntuacion=puntuacion+0}
        if(group4 == "B") {puntuacion=puntuacion+0}
        if(group4 == "C") {puntuacion=puntuacion+10}
      }
      else {nocontesta=nocontesta+1}
      
      if(group5!= "0" ){
        contestadas=contestadas+1
        puntosmaximos=puntosmaximos+10
        if(group5 == "A") {puntuacion=puntuacion+0}
        if(group5 == "B") {puntuacion=puntuacion+0}
        if(group5 == "C") {puntuacion=puntuacion+10}
        
      }
      else {nocontesta=nocontesta+1} 
      
      
      if (puntosmaximos!=0) 
      {indiceacierto=Math.round(100*(puntuacion/puntosmaximos))
      } 
      else{indiceacierto=0} 
      
      
      if(indiceacierto<=100&&indiceacierto>=90) 
      {
      mensaje="Excelente Muy Bien Sigue Asi"} 
      
      if(indiceacierto<90&&indiceacierto>=80)
      {
      mensaje="Muy Bien"} 
      
      if(indiceacierto<70&&indiceacierto>=60)
      {
      mensaje="Regular Deverias Estudiar Mas"} 
      
      if(indiceacierto<50&&indiceacierto>=30)
      {
      mensaje="Mal Echale Ganas"} 
      
      if(indiceacierto<20&&indiceacierto>=0)
      {
      mensaje="REPROBADOOO!!!!"} 
      
      if(contestadas==0)
      {
      mensaje=":-|"} 
      
      alert("Tu puntuación es "+puntuacion+"." +  "\n\nEl número máximo de puntos que podía conseguir era de " + puntosmaximos + ".\n\nHa dejado sin contestar "+ nocontesta+".\n\nSu porcentaje de aciertos es de "+indiceacierto+"%.\n\n"+mensaje+". ") 
      
      }   
   =
      
        function examinar() 
        { 
        puntuacion=0; 
        nocontesta=0; 
        contestadas=0; 
        puntosmaximos=0; 
        
        if(group1!= "0" )
        {
          contestadas=contestadas+1
          puntosmaximos=puntosmaximos+10
          if(group1 == "A") {puntuacion=puntuacion+0}
          if(group1 == "B") {puntuacion=puntuacion+0}
          if(group1 == "C") {puntuacion=puntuacion+10}
        
        }
        else {nocontesta=nocontesta+1} 
        
        if(group2 != "0")
        {
          contestadas=contestadas+1
          puntosmaximos=puntosmaximos+10
          if(group2 == "A") {puntuacion=puntuacion+0}
          if(group2 == "B") {puntuacion=puntuacion+10}
          if(group2 == "C") {puntuacion=puntuacion+0}
          
        }
        else {nocontesta=nocontesta+1}
        
        if(group3!= "0" )
        {
          contestadas=contestadas+1
          puntosmaximos=puntosmaximos+10
          if(group3 == "A") {puntuacion=puntuacion+10}
          if(group3 == "B") {puntuacion=puntuacion+0}
          if(group3 == "C") {puntuacion=puntuacion+0}
          
        }
        else {nocontesta=nocontesta+1} 
        
        if(group4 != "0")
        {
          contestadas=contestadas+1
          puntosmaximos=puntosmaximos+10
          if(group4 == "A") {puntuacion=puntuacion+0}
          if(group4 == "B") {puntuacion=puntuacion+0}
          if(group4 == "C") {puntuacion=puntuacion+10}
        }
        else {nocontesta=nocontesta+1}
        
        if(group5!= "0" ){
          contestadas=contestadas+1
          puntosmaximos=puntosmaximos+10
          if(group5 == "A") {puntuacion=puntuacion+0}
          if(group5 == "B") {puntuacion=puntuacion+0}
          if(group5 == "C") {puntuacion=puntuacion+10}
          
        }
        else {nocontesta=nocontesta+1} 
        
        
        if (puntosmaximos!=0) 
        {indiceacierto=Math.round(100*(puntuacion/puntosmaximos))
        } 
        else{indiceacierto=0} 
        
        
        if(indiceacierto<=100&&indiceacierto>=90) 
        {
        mensaje="Excelente Muy Bien Sigue Asi"} 
        
        if(indiceacierto<90&&indiceacierto>=80)
        {
        mensaje="Muy Bien"} 
        
        if(indiceacierto<70&&indiceacierto>=60)
        {
        mensaje="Regular Deverias Estudiar Mas"} 
        
        if(indiceacierto<50&&indiceacierto>=30)
        {
        mensaje="Mal Echale Ganas"} 
        
        if(indiceacierto<20&&indiceacierto>=0)
        {
        mensaje="REPROBADOOO!!!!"} 
        
        if(contestadas==0)
        {
        mensaje=":-|"} 
        
        alert("Tu puntuación es "+puntuacion+"." +  "\n\nEl número máximo de puntos que podía conseguir era de " + puntosmaximos + ".\n\nHa dejado sin contestar "+ nocontesta+".\n\nSu porcentaje de aciertos es de "+indiceacierto+"%.\n\n"+mensaje+". ") 
        
        }
        